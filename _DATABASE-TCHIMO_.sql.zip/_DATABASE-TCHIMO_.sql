-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:8889
-- Généré le : mer. 01 déc. 2021 à 15:43
-- Version du serveur :  5.7.32
-- Version de PHP : 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `tchimo`
--

-- --------------------------------------------------------

--
-- Structure de la table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Prof. Muhammad Mayer', 'crooks.lorine@example.net', '2021-11-30 12:07:30', '$2y$10$7NpOkVpXsNDvyZ08m2o0GOCYc/27foAVtEAx/PODtIf5pmzunpG0q', 'gsZTf77FhD', '2021-11-30 12:07:30', '2021-11-30 12:07:30'),
(2, 'Otis Mueller DDS', 'zena.lowe@example.org', '2021-11-30 12:07:30', '$2y$10$a0tbylCVPmYXvIag3EIEN.8qLfXoexN9geOCy29RR6uyJU4n898Ti', 'ob7TX1y2Gu', '2021-11-30 12:07:30', '2021-11-30 12:07:30'),
(3, 'Ms. Amber Pacocha', 'beatty.wava@example.org', '2021-11-30 12:07:30', '$2y$10$3LcAXXH/qF88S7FGxeYgYOt0sXH8VspTIfdANl0ZESykz6Nnv6asq', 'PFYl5R9Qrg', '2021-11-30 12:07:30', '2021-11-30 12:07:30'),
(4, 'Mustafa Kuhn DVM', 'jenkins.maudie@example.net', '2021-11-30 12:07:30', '$2y$10$zB31z8gPpujd0RjXlGI55OKqw77t8fDdeVldZgneVpUCWxuXlfwNK', '1FwPSm5Icd', '2021-11-30 12:07:30', '2021-11-30 12:07:30'),
(5, 'Tiana Bartoletti', 'gina10@example.org', '2021-11-30 12:07:30', '$2y$10$OsmlzcBag2tJDU3iI.W5r.tg48hUsmhu3E7vVTCoE5eAr6TNlBARa', 'gddHvooFYk', '2021-11-30 12:07:30', '2021-11-30 12:07:30'),
(6, 'Mose Goodwin', 'ines.beatty@example.org', '2021-11-30 12:33:06', '$2y$10$BtJXp9TkuAOwFYli4COamuQX0y7ZxXCtF8cou3gcmmmbriVHB23gK', 'I4rBmoqeWf', '2021-11-30 12:33:06', '2021-11-30 12:33:06'),
(7, 'Maximillia Moen', 'ward.gertrude@example.net', '2021-11-30 12:33:06', '$2y$10$Ncr.lZNTNedokatgnYjJOuMxuVNjxcxq7kYpaoPWFk1hq/W6.FsYi', 'R1K3dEIoyG', '2021-11-30 12:33:06', '2021-11-30 12:33:06'),
(8, 'Eveline Watsica', 'yfranecki@example.com', '2021-11-30 12:33:06', '$2y$10$GFBFk2PzUfPwM4J5WEW7EenGlvueHGn9T6z4egNLquRHInJocx1FG', 'QCnWtW54ui', '2021-11-30 12:33:06', '2021-11-30 12:33:06'),
(9, 'Guadalupe Paucek', 'zoila.reichert@example.org', '2021-11-30 12:33:06', '$2y$10$7Dys./KKc4EoiEmFEjao3.oAnjgOkEO5VHsTTtis3nFoKzJTeH1fy', 'pW5Gsa9rfC', '2021-11-30 12:33:06', '2021-11-30 12:33:06'),
(10, 'Mrs. Gloria Lueilwitz', 'sarina50@example.com', '2021-11-30 12:33:06', '$2y$10$JiRqWWpXhLUduoLPUecJ0O72P4geklUKm6kCXHe4LANQB/fqszWKq', 'ehnDjqzKk3', '2021-11-30 12:33:06', '2021-11-30 12:33:06');

-- --------------------------------------------------------

--
-- Structure de la table `columns`
--

CREATE TABLE `columns` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tables_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `comments`
--

CREATE TABLE `comments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `text_comment` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `users_id` int(11) NOT NULL,
  `tickets_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2021_11_24_090606_create_tables_table', 1),
(6, '2021_11_24_093448_create_columns_table', 1),
(7, '2021_11_24_094355_create_tickets_table', 1),
(8, '2021_11_24_095705_create_comments_table', 1),
(9, '2021_11_28_181023_create_admins_table', 1);

-- --------------------------------------------------------

--
-- Structure de la table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `tables`
--

CREATE TABLE `tables` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `users_id` int(11) NOT NULL,
  `table_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `guests` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `tables`
--

INSERT INTO `tables` (`id`, `created_at`, `updated_at`, `users_id`, `table_name`, `status`, `guests`) VALUES
(1, '2021-12-01 15:10:48', '2021-12-01 15:10:48', 1, 'huhuhuhu', 1, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `tickets`
--

CREATE TABLE `tickets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `qtt_comments` int(11) NOT NULL,
  `columns_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Dr. Mara D\'Amore I', 'jeanie80@example.com', '2021-11-30 12:37:23', '$2y$10$32Xg42is3aXp4zCT8rBoHuMzFs0DlMGPR/WHcS1kD539k0XJY8YnW', 'bqoFdZ01lioFcIR4Tzoki2fp0IKVL0hkNmVlBSGpZGZ5DYh7H0mnXCfPdfFQ', '2021-11-30 12:37:23', '2021-11-30 12:37:23'),
(2, 'Mrs. Iliana Harvey', 'xrolfson@example.net', '2021-11-30 12:37:23', '$2y$10$hnogVk7zhM.Ms5GIrl/FK..ZDYpyDiARiiALe4xDkbXqnol5jII2W', '9rZDBB9hob', '2021-11-30 12:37:23', '2021-11-30 12:37:23'),
(3, 'Jeanie Streich', 'courtney.hermiston@example.net', '2021-11-30 12:37:23', '$2y$10$ME7ZR0mmLnjSit2JN6W0wutJtOVuDt3oJWWJjmKXySKefqfVu7H/W', 'euj62SCGBu', '2021-11-30 12:37:23', '2021-11-30 12:37:23'),
(4, 'Mr. Dejuan Green PhD', 'sydney83@example.org', '2021-11-30 12:37:23', '$2y$10$WJMnbx72gy4cjgjuJrsl1OAyxo4jQQ4VGPaOhjc0Y77ChEg7RiEYe', 'tY5zfJwu2N', '2021-11-30 12:37:23', '2021-11-30 12:37:23'),
(5, 'Mr. Steve Mitchell MD', 'shanel88@example.org', '2021-11-30 12:37:23', '$2y$10$JMPmiOvgXABkJ1eIwYCZoeEniTA92ADmB1o7rVHxHw6YbyuJ7tRem', '3J9nw5hYry', '2021-11-30 12:37:23', '2021-11-30 12:37:23');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admins_email_unique` (`email`);

--
-- Index pour la table `columns`
--
ALTER TABLE `columns`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `columns_name_unique` (`name`);

--
-- Index pour la table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Index pour la table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Index pour la table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Index pour la table `tables`
--
ALTER TABLE `tables`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tables_table_name_unique` (`table_name`);

--
-- Index pour la table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT pour la table `columns`
--
ALTER TABLE `columns`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT pour la table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `tables`
--
ALTER TABLE `tables`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `tickets`
--
ALTER TABLE `tickets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
